/* Shared behaviour for course pages: theme, accessibility, menu, dropdown, full screen, WhatsApp, back to top, enquiry form */
(function(){
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))},R=document.documentElement;
/* Theme: follows local time until the visitor chooses */
var TK='aima_theme',mp=null;try{mp=localStorage.getItem(TK)}catch(e){}
var tb=$('#themeBtn'),ta=$('#tauto');
function themeApply(){var h=new Date().getHours(),man=(mp==='dark'||mp==='light'),m=man?mp:((h>=18||h<6)?'dark':'light');R.setAttribute('data-theme',m);tb.setAttribute('aria-label','Switch to '+(m==='dark'?'light':'dark')+' mode');tb.title=tb.getAttribute('aria-label');ta.hidden=!man}
function themeSave(v){mp=v;try{v?localStorage.setItem(TK,v):localStorage.removeItem(TK)}catch(e){}themeApply()}
tb.onclick=function(){themeSave(R.getAttribute('data-theme')==='dark'?'light':'dark')};ta.onclick=function(){themeSave(null)};themeApply();setInterval(themeApply,60000);
/* Toast and full screen */
var te=$('#toast'),tt0;function toast(m){te.textContent=m;te.classList.add('show');clearTimeout(tt0);tt0=setTimeout(function(){te.classList.remove('show')},4000)}
var fsb=$('#fsBtn');function fsOn(){return!!(document.fullscreenElement||document.webkitFullscreenElement)}
function fsSync(){var on=fsOn(),t=on?'Exit full screen':'Enter full screen';fsb.setAttribute('aria-label',t);fsb.title=t;fsb.classList.toggle('on',on)}
fsb.onclick=function(){var req=R.requestFullscreen||R.webkitRequestFullscreen,ex=document.exitFullscreen||document.webkitExitFullscreen,msg='Full screen is not available in this view. Open the page in its own browser tab to use it.';
if(!req||!(document.fullscreenEnabled||document.webkitFullscreenEnabled)){toast(msg);return}
try{var p=fsOn()?ex.call(document):req.call(R);if(p&&p.catch)p.catch(function(){toast(msg)})}catch(e){toast(msg)}};
document.addEventListener('fullscreenchange',fsSync);document.addEventListener('webkitfullscreenchange',fsSync);
/* Accessibility panel */
var AK='aima_a11y',A={z:0,c:0,f:0,l:0,m:0},ZS=[1,1.15,1.3,1.5],AF={c:'data-contrast',f:'data-font',l:'data-links',m:'data-still'};
try{var sv=JSON.parse(localStorage.getItem(AK)||'null');if(sv)for(var q in A)if(typeof sv[q]==='number')A[q]=sv[q]}catch(e){}
function logoFit(){var a=$('.lt .l1'),b=$('.lt .l2');if(!a||!b)return;b.style.letterSpacing='0px';b.style.marginRight='0px';var w1=a.offsetWidth,w2=b.offsetWidth,n=b.textContent.length,L=Math.max(0,(w1-w2)/(n-1));b.style.letterSpacing=L.toFixed(2)+'px';b.style.marginRight=(-L).toFixed(2)+'px'}
function aApply(){for(var k in AF)R.toggleAttribute(AF[k],!!A[k]);$('.wrap').style.zoom=ZS[A.z]===1?'':ZS[A.z];$('#zLbl').textContent='Text size: '+Math.round(ZS[A.z]*100)+'%';$('#zDn').disabled=A.z===0;$('#zUp').disabled=A.z===ZS.length-1;
$$('.sw').forEach(function(b){var on=!!A[b.dataset.k];b.setAttribute('aria-pressed',on?'true':'false');b.dataset.s=on?'On':'Off'});try{localStorage.setItem(AK,JSON.stringify(A))}catch(e){}logoFit()}
var ab=$('#a11yBtn'),abx=$('#a11yBox');function aToggle(o){abx.hidden=!o;ab.setAttribute('aria-expanded',o?'true':'false');if(o)$('.ab:not(:disabled)',abx).focus()}
ab.onclick=function(){aToggle(abx.hidden)};$('#a11yX').onclick=function(){aToggle(false);ab.focus()};
$('#zDn').onclick=function(){if(A.z>0){A.z--;aApply()}};$('#zUp').onclick=function(){if(A.z<ZS.length-1){A.z++;aApply()}};
$$('.sw').forEach(function(b){b.onclick=function(){A[b.dataset.k]=A[b.dataset.k]?0:1;aApply()}});
$('#a11yR').onclick=function(){A={z:0,c:0,f:0,l:0,m:0};aApply()};aApply();
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(logoFit);window.addEventListener('resize',logoFit);
/* Mobile menu and Courses dropdown */
var bg=$('#burger'),nv=$('#mainnav'),dd=$('#dd'),ddT=$('#ddT');
bg.onclick=function(){var o=nv.classList.toggle('open');bg.setAttribute('aria-expanded',o?'true':'false')};
nv.onclick=function(e){if(e.target.closest('a')&&!e.target.closest('.ddt')){nv.classList.remove('open');bg.setAttribute('aria-expanded','false')}};
function ddSet(o){dd.classList.toggle('open',o);ddT.setAttribute('aria-expanded',o?'true':'false')}
ddT.onclick=function(e){if(matchMedia('(hover:none)').matches||innerWidth<=700){e.preventDefault();ddSet(!dd.classList.contains('open'))}};
$('#ddM').onclick=function(e){if(e.target.closest('a')){ddSet(false);dd.classList.add('shut')}};
dd.addEventListener('mouseleave',function(){dd.classList.remove('shut')});
document.addEventListener('click',function(e){if(!dd.contains(e.target))ddSet(false)});
document.addEventListener('keydown',function(e){if(e.key!=='Escape')return;if(!abx.hidden){aToggle(false);ab.focus()}if(dd.classList.contains('open')){ddSet(false);ddT.focus()}});
/* Back to top and WhatsApp assistant */
var tp=$('#toTop');function tpc(){tp.classList.toggle('show',window.scrollY>500)}window.addEventListener('scroll',tpc,{passive:true});tpc();
tp.onclick=function(){window.scrollTo({top:0,behavior:A.m?'auto':'smooth'})};
var wt=$('#waToggle'),wb=$('#waBox');wt.onclick=function(){var o=wb.hidden;wb.hidden=!o;wt.setAttribute('aria-expanded',o?'true':'false')};
/* Curriculum: expand or collapse all modules */
var ex=$('#expandAll');if(ex)ex.onclick=function(){var ds=$$('.mods details'),all=ds.every(function(x){return x.open});ds.forEach(function(x){x.open=!all});ex.textContent=all?'Expand all modules':'Collapse all modules'};
/* In-page navigation highlight */
var sn=$$('.subnav a');if(window.IntersectionObserver&&sn.length){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)sn.forEach(function(a){a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id)})})},{rootMargin:'-30% 0px -60% 0px'});sn.forEach(function(a){var s=$(a.getAttribute('href'));if(s)io.observe(s)})}
/* Enquiry form: opens an email to the academy */
var f=$('#form');if(f)f.onsubmit=function(e){e.preventDefault();var n=$('#name').value.trim(),m=$('#email').value.trim(),p=$('#phone').value.trim(),er=$('#err'),ok=$('#ok');er.textContent='';
if(n.length<2){er.textContent='Enter your full name.';return}if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m)){er.textContent='Enter a valid email address, like name@example.com.';return}if(p.replace(/\D/g,'').length<10){er.textContent='Enter a phone number with at least 10 digits.';return}
var c=f.dataset.course,md=$('#mode').value,to=f.dataset.email,href='mailto:'+to+'?subject='+encodeURIComponent('Course enquiry: '+c)+'&body='+encodeURIComponent('Name: '+n+'\nEmail: '+m+'\nPhone: '+p+'\nCourse: '+c+'\nPreferred mode: '+md+'\n\nSent from the AI Masters Academy website.');
var a=document.createElement('a');a.href=href;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
ok.hidden=false;ok.textContent='Thank you, '+n.split(' ')[0]+'. Your email for '+c+' is ready to send. Press Send in your email app to deliver it to us. ';var l=document.createElement('a');l.href=href;l.target='_blank';l.rel='noopener';l.textContent='Email app did not open? Click here.';ok.appendChild(l);f.reset()};
})();
